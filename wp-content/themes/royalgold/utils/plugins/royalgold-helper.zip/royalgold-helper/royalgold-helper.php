<?php
/*
Plugin Name: RoyalGold Helper
Plugin URI: http://themeforest.net/user/liviu_cerchez
Description: Shortcodes for the RoyalGold theme (and other useful features)
Version: 1.0
Author: liviu_cerchez
Author URI: http://themeforest.net/user/liviu_cerchez
*/

require_once( plugin_dir_path( __FILE__ ) . 'utils' . DIRECTORY_SEPARATOR . 'shortcodes.php' );
