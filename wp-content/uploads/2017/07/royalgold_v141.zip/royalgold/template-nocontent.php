<?php
/**
 *	Template Name: No Content Page
 *
 *	The template for displaying custom pages in fullscreen mode
 */

get_header();
the_post();
get_footer();