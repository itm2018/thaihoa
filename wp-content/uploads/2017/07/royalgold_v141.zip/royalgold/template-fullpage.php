<?php
/**
 *	Template Name: Full-page Gallery
 *
 *	The template for displaying custom pages in fullscreen mode
 */

get_header();
the_post();
get_footer();