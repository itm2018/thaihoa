<p><?php _e( 'Apologies, but no results were found for the requested page. <br />Perhaps searching will help find a related item.', 'royalgold' ); ?></p>
<?php get_search_form(); ?>