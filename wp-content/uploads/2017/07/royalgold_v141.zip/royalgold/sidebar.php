<?php

if ( is_active_sidebar('page-sidebar')) {
	dynamic_sidebar('page-sidebar');
}